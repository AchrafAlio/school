# -*- coding: utf-8 -*-
from odoo import api, fields, models


class SchoolTeacher(models.Model):
    _name = "school.teacher"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Teacher"

    teacher_name = fields.Char(string='Teacher Name', required=True, tracking=True)
    picture = fields.Binary(string='Picture')
