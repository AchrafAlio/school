# -*- coding: utf-8 -*-
from odoo import api, fields, models


class SchoolClass(models.Model):
    _name = "school.class"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Class"

    name = fields.Char(string='Name', required=True, tracking=True)
    capacity = fields.Integer(string='Capacity')
    total_students = fields.Integer(string='Total Students')
    remaining_seats = fields.Integer(string='Remaining Seats')
    color = fields.Char(string='Color')
    standard_id = fields.Many2one('school.standard', string="Standard")
    teacher_id = fields.Many2one('school.teacher', string="Teacher")
    classroom_id = fields.Many2one('school.classroom', string="Room Number")
    student_ids = fields.One2many('school.student', 'id', string="Students")
    subject_ids = fields.One2many('school.subject', 'id', string="Subjects")


class SchoolStandard(models.Model):
    _name = "school.standard"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Standard"

    name = fields.Char(string='Name', required=True, tracking=True)
    sequence = fields.Char(string='Sequence')
    code = fields.Char(string='Code')
    description = fields.Char(string='Description')


class SchoolClassroom(models.Model):
    _name = "school.classroom"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Classroom"

    name = fields.Char(string='Name', required=True, tracking=True)
    room_number = fields.Char(string='Room Number')


class SchoolSubject(models.Model):
    _name = "school.subject"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Subject"

    name = fields.Char(string='Name', required=True, tracking=True)
    code = fields.Char(string='Code')
    standard_ids = fields.One2many('school.standard', 'id', string="Standards")
    teacher_ids = fields.One2many('school.teacher', 'id', string="Teachers")



