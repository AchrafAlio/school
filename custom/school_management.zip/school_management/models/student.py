# -*- coding: utf-8 -*-
from odoo import api, fields, models


class SchoolStudent(models.Model):
    _name = "school.student"
    _inherits = {'res.partner': 'partner_id'}
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "School Student"

    student_number = fields.Char(string='Student Number', required=True, tracking=True)
    roll_number = fields.Char(string='Roll number')
    birth_date = fields.Date(string='Birth Date')
    class_id = fields.Many2one('school.class', string='Class')
    admission_age = fields.Integer(string='Admission Age', required=True, tracking=True)
    admission_date = fields.Date(string='Admission Date')
    class_id = fields.Many2one('school.class', string='Class')
    state = fields.Selection([('new', 'New'), ('approved', 'Approved'), ('alumni', 'Alumni'),
                              ('terminate', 'Terminate'), ('cancel', 'Cancelled')],
                             string='Status', tracking=True, default="new")

