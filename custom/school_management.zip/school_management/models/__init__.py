from . import res_config_settings
from . import school
from . import student
from . import teacher
